/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.du.fatecpg.poo;
import java.util.ArrayList;
/**
 *
 * @author mandi
 */
public class User {
    private String name;
    private String email;
    private String telefone;
    
    public static ArrayList<User> getList(){
        ArrayList<User> list = new ArrayList<>();
        list.add(new User("", "", ""));
        list.add(new User("", "", ""));
        list.add(new User("", "", ""));
        list.add(new User("", "", ""));
                return list;
    }
      
    public User(String name, String email, String telefone){
        this.name = name;
        this.telefone = telefone;
        this.email = email;
    }
  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
}






